package br.com.uniamerica.trasnportadora.transportadoraapi.repository;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Cidade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CidadeRepository extends JpaRepository<Cidade, Long> {
}
