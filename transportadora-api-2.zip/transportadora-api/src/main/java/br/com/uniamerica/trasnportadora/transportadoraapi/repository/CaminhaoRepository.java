package br.com.uniamerica.trasnportadora.transportadoraapi.repository;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Caminhao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CaminhaoRepository extends JpaRepository<Caminhao, Long> {
}
