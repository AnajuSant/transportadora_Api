package br.com.uniamerica.trasnportadora.transportadoraapi.controller;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Cidade;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Estado;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.EstadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/api/estado")
public class EstadoController {
    @Autowired
    private EstadoRepository estadoRepository;

    @PostMapping
    public ResponseEntity<String> Post(@RequestBody final Estado estado){
        try{
            this.estadoRepository.save(estado);
            return ResponseEntity.ok().body("Estado saved successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<String> Put(@PathVariable final Long id, @RequestBody final Cidade cidade){
        try{
            Optional<Estado> res = this.estadoRepository.findById(id);
            Estado existingEstado = res.orElseThrow(() -> new Exception("Estado não encontrado"));

            existingEstado.setNome(existingEstado.getNome());


            this.estadoRepository.save(existingEstado);
            return ResponseEntity.ok().body("Estado updated successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> Delete(@PathVariable final Long id){
        try{
            Optional<Estado> res = this.estadoRepository.findById(id);
            Estado existingEstado = res.orElseThrow(() -> new Exception("Estado não encontrado"));

            this.estadoRepository.delete(existingEstado);
            return ResponseEntity.ok().body("Estado deleted successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> GetById(@PathVariable final Long id){
        try{
            Optional<Estado> res = this.estadoRepository.findById(id);
            Estado existingEstado = res.orElseThrow(() -> new Exception("Estado não encontrado"));

            return ResponseEntity.ok().body(existingEstado);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping()
    public ResponseEntity<?> GetById(){
        try{
            List<Estado> estados = this.estadoRepository.findAll();

            return ResponseEntity.ok().body(estados);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
