package br.com.uniamerica.trasnportadora.transportadoraapi.entity;

public enum Cor {
    branco,
    preto,
    cinza,
    vermelho,
    azul,
    amarelo,
}
