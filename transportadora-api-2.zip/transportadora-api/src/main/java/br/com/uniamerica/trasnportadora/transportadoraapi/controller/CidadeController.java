package br.com.uniamerica.trasnportadora.transportadoraapi.controller;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Cidade;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Modelo;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.CidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/api/cidade")
public class CidadeController {
    @Autowired
    private CidadeRepository cidadeRepository;

    @PostMapping
    public ResponseEntity<String> Post(@RequestBody final Cidade cidade){
        try{
            this.cidadeRepository.save(cidade);
            return ResponseEntity.ok().body("Cidade saved successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<String> Put(@PathVariable final Long id, @RequestBody final Cidade cidade){
        try{
            Optional<Cidade> res = this.cidadeRepository.findById(id);
            Cidade existingCidade = res.orElseThrow(() -> new Exception("Cidade não encontrada"));

            existingCidade.setNome(existingCidade.getNome());
            existingCidade.setEstado(existingCidade.getEstado());


            this.cidadeRepository.save(existingCidade);
            return ResponseEntity.ok().body("Cidade updated successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> Delete(@PathVariable final Long id){
        try{
            Optional<Cidade> res = this.cidadeRepository.findById(id);
            Cidade existingCidade = res.orElseThrow(() -> new Exception("Cidade não encontrada"));

            this.cidadeRepository.delete(existingCidade);
            return ResponseEntity.ok().body("Cidade deleted successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> GetById(@PathVariable final Long id){
        try{
            Optional<Cidade> res = this.cidadeRepository.findById(id);
            Cidade existingCidade = res.orElseThrow(() -> new Exception("Cidade não encontrada"));

            return ResponseEntity.ok().body(existingCidade);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping()
    public ResponseEntity<?> GetById(){
        try{
            List<Cidade> cidades = this.cidadeRepository.findAll();

            return ResponseEntity.ok().body(cidades);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
