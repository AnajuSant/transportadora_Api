package br.com.uniamerica.trasnportadora.transportadoraapi.controller;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Cidade;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Estado;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Produto;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/api/produto")
public class ProdutoController {
    @Autowired
    private ProdutoRepository produtoRepository;

    @PostMapping
    public ResponseEntity<String> Post(@RequestBody final Produto produto){
        try{
            this.produtoRepository.save(produto);
            return ResponseEntity.ok().body("Produto saved successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<String> Put(@PathVariable final Long id, @RequestBody Produto produto){
        try{
            Optional<Produto> res = this.produtoRepository.findById(id);
            Produto existingProduto = res.orElseThrow(() -> new Exception("Produto não encontrado"));

            existingProduto.setNome(existingProduto.getNome());

            this.produtoRepository.save(existingProduto);
            return ResponseEntity.ok().body("Produto updated successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> Delete(@PathVariable final Long id){
        try{
            Optional<Produto> res = this.produtoRepository.findById(id);
            Produto existingProduto = res.orElseThrow(() -> new Exception("Produto não encontrado"));

            this.produtoRepository.delete(existingProduto);
            return ResponseEntity.ok().body("Produto deleted successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> GetById(@PathVariable final Long id){
        try{
            Optional<Produto> res = this.produtoRepository.findById(id);
            Produto existingProduto = res.orElseThrow(() -> new Exception("Produto não encontrado"));

            return ResponseEntity.ok().body(existingProduto);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping()
    public ResponseEntity<?> GetById(){
        try{
            List<Produto> produtos = this.produtoRepository.findAll();

            return ResponseEntity.ok().body(produtos);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
