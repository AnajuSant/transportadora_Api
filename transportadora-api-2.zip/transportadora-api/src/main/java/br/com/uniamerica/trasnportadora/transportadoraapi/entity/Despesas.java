package br.com.uniamerica.trasnportadora.transportadoraapi.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name= "td_despesas", schema = "transportadora")
public class Despesas extends AbstractEntity{

    @Getter
    @Setter
    @ManyToOne
    private TipoDespesa tipoDespesa;

    @Getter @Setter
    private BigDecimal valor;

    @Getter @Setter
    @ManyToOne
    private Usuario motorista;

    @Getter @Setter
    private LocalDateTime data;

    @Getter @Setter
    @ManyToOne
    private Usuario aprovador;

    @Getter @Setter
    @ManyToOne
    private Frete frete;
}
