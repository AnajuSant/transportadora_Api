package br.com.uniamerica.trasnportadora.transportadoraapi.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name= "td_historicoFrete", schema = "transportadora")
public class HistoricoFrete extends AbstractEntity{

    @Getter
    @Setter
    private LocalDateTime data;

    @Getter @Setter
    @ManyToOne
    private Frete frete;

    @Getter @Setter
    private StatusFrete statusFrete;

    @Getter @Setter
    @ManyToOne
    private Usuario executor;

}
