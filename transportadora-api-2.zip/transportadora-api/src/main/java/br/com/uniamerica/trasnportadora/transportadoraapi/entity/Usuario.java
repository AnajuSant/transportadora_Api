package br.com.uniamerica.trasnportadora.transportadoraapi.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;
import java.math.BigDecimal;

@Entity
@Table(name= "td_usuario", schema = "transportadora")
public class Usuario extends AbstractEntity{

    @Getter
    @Setter
    private BigDecimal percoGanho;

    @Getter @Setter
    private String login;

    @Getter @Setter
    private String senha;

    @Getter @Setter
    private Grupo grupo;

    @Getter @Setter
    private String nome;

    @Getter @Setter
    private String cpf;

    @Getter @Setter
    private String telefone;

    @Getter @Setter
    private LocalDate dataNascimento;

    @Getter @Setter
    private String endereco;

    @Getter @Setter
    private String observacao;


}
