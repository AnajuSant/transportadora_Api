package br.com.uniamerica.trasnportadora.transportadoraapi.entity;

public enum Grupo {
    motorista,
    administrador
}
