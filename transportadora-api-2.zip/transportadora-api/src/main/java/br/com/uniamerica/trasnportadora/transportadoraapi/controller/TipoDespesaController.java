package br.com.uniamerica.trasnportadora.transportadoraapi.controller;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Cidade;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Estado;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.TipoDespesa;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.TipoDespesaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/api/tipodespesa")
public class TipoDespesaController {
    @Autowired
    private TipoDespesaRepository tipoDespesaRepository;

    @PostMapping
    public ResponseEntity<String> Post(@RequestBody final TipoDespesa tipoDespesa){
        try{
            this.tipoDespesaRepository.save(tipoDespesa);
            return ResponseEntity.ok().body("Tipo Despesa saved successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<String> Put(@PathVariable final Long id, @RequestBody final TipoDespesa tipoDespesa){
        try{
            Optional<TipoDespesa> res = this.tipoDespesaRepository.findById(id);
            TipoDespesa existingTipoDespesa = res.orElseThrow(() -> new Exception("Tipo Despesa não encontrada"));

            existingTipoDespesa.setNome(tipoDespesa.getNome());

            this.tipoDespesaRepository.save(existingTipoDespesa);
            return ResponseEntity.ok().body("Tipo Despesa updated successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> Delete(@PathVariable final Long id){
        try{
            Optional<TipoDespesa> res = this.tipoDespesaRepository.findById(id);
            TipoDespesa existingTipoDespesa = res.orElseThrow(() -> new Exception("Tipo Despesa não encontrada"));

            this.tipoDespesaRepository.delete(existingTipoDespesa);
            return ResponseEntity.ok().body("Tipo Despesa deleted successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> GetById(@PathVariable final Long id){
        try{
            Optional<TipoDespesa> res = this.tipoDespesaRepository.findById(id);
            TipoDespesa existingTipoDespesa = res.orElseThrow(() -> new Exception("Tipo Despesa não encontrada"));

            return ResponseEntity.ok().body(existingTipoDespesa);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping()
    public ResponseEntity<?> GetById(){
        try{
            List<TipoDespesa> tipoDespesas = this.tipoDespesaRepository.findAll();

            return ResponseEntity.ok().body(tipoDespesas);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
