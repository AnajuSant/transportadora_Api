package br.com.uniamerica.trasnportadora.transportadoraapi.controller;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Caminhao;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Usuario;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.CaminhaoRepository;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/api/caminhao")
public class CaminhaoController {
    @Autowired
    private CaminhaoRepository caminhaoRepository;

    @PostMapping
    public ResponseEntity<String> Post(@RequestBody final Caminhao caminhao){
        try{
            this.caminhaoRepository.save(caminhao);
            return ResponseEntity.ok().body("Truck saved successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<String> Put(@PathVariable final Long id, @RequestBody final Caminhao caminhao){
        try{
            Optional<Caminhao> res = this.caminhaoRepository.findById(id);
            Caminhao existingCaminhao = res.orElseThrow(() -> new Exception("Caminhao não encontrado"));

            existingCaminhao.setAno(caminhao.getAno());
            existingCaminhao.setCor(caminhao.getCor());
            existingCaminhao.setModelo(caminhao.getModelo());
            existingCaminhao.setPlaca(caminhao.getPlaca());
            existingCaminhao.setMotorista(caminhao.getMotorista());

            this.caminhaoRepository.save(existingCaminhao);
            return ResponseEntity.ok().body("Caminhao updated successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> Delete(@PathVariable final Long id){
        try{
            Optional<Caminhao> res = this.caminhaoRepository.findById(id);
            Caminhao existingCaminhao = res.orElseThrow(() -> new Exception("Caminhao não encontrado"));

            this.caminhaoRepository.delete(existingCaminhao);
            return ResponseEntity.ok().body("Caminhao deleted successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> GetById(@PathVariable final Long id){
        try{
            Optional<Caminhao> res = this.caminhaoRepository.findById(id);
            Caminhao existingCaminhao = res.orElseThrow(() -> new Exception("Caminhao não encontrado"));

            return ResponseEntity.ok().body(existingCaminhao);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping()
    public ResponseEntity<?> GetById(){
        try{
            List<Caminhao> caminhoes = this.caminhaoRepository.findAll();

            return ResponseEntity.ok().body(caminhoes);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
