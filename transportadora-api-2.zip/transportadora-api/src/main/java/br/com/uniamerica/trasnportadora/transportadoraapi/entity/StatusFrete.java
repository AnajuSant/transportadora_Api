package br.com.uniamerica.trasnportadora.transportadoraapi.entity;

public enum StatusFrete {
    carga,
    em_transporte,
    interrompido,
    descarga,
    faturado,
    cancelado
}
