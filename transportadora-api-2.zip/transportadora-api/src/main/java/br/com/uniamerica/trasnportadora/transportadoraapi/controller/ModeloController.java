package br.com.uniamerica.trasnportadora.transportadoraapi.controller;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Marca;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Modelo;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.ModeloRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/api/modelo")
public class ModeloController {
    @Autowired
    private ModeloRepository modeloRepository;

    @PostMapping
    public ResponseEntity<String> Post(@RequestBody final Modelo modelo){
        try{
            this.modeloRepository.save(modelo);
            return ResponseEntity.ok().body("Modelo saved successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<String> Put(@PathVariable final Long id, @RequestBody final Modelo modelo){
        try{
            Optional<Modelo> res = this.modeloRepository.findById(id);
            Modelo existingModelo = res.orElseThrow(() -> new Exception("Modelo não encontrado"));

            existingModelo.setNome(modelo.getNome());
            existingModelo.setMarca(modelo.getMarca());


            this.modeloRepository.save(existingModelo);
            return ResponseEntity.ok().body("Modelo updated successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> Delete(@PathVariable final Long id){
        try{
            Optional<Modelo> res = this.modeloRepository.findById(id);
            Modelo existingModelo = res.orElseThrow(() -> new Exception("Modelo não encontrado"));

            this.modeloRepository.delete(existingModelo);
            return ResponseEntity.ok().body("Modelo deleted successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> GetById(@PathVariable final Long id){
        try{
            Optional<Modelo> res = this.modeloRepository.findById(id);
            Modelo existingModelo = res.orElseThrow(() -> new Exception("Modelo não encontrado"));

            return ResponseEntity.ok().body(existingModelo);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping()
    public ResponseEntity<?> GetById(){
        try{
            List<Modelo> modelos = this.modeloRepository.findAll();

            return ResponseEntity.ok().body(modelos);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
