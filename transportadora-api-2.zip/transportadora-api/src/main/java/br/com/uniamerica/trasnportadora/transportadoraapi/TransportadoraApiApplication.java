package br.com.uniamerica.trasnportadora.transportadoraapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransportadoraApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransportadoraApiApplication.class, args);
	}

}
