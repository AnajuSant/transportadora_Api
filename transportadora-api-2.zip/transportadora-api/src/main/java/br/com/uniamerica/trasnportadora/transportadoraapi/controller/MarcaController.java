package br.com.uniamerica.trasnportadora.transportadoraapi.controller;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Caminhao;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Marca;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.MarcaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/api/marca")
public class MarcaController {
    @Autowired
    private MarcaRepository marcaRepository;

    @PostMapping
    public ResponseEntity<String> Post(@RequestBody final Marca marca){
        try{
            this.marcaRepository.save(marca);
            return ResponseEntity.ok().body("Marca saved successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<String> Put(@PathVariable final Long id, @RequestBody final Marca marca){
        try{
            Optional<Marca> res = this.marcaRepository.findById(id);
            Marca existingMarca = res.orElseThrow(() -> new Exception("Marca não encontrada"));

            existingMarca.setValor(marca.getValor());

            this.marcaRepository.save(existingMarca);
            return ResponseEntity.ok().body("Marca updated successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> Delete(@PathVariable final Long id){
        try{
            Optional<Marca> res = this.marcaRepository.findById(id);
            Marca existingMarca = res.orElseThrow(() -> new Exception("Marca não encontrada"));

            this.marcaRepository.delete(existingMarca);
            return ResponseEntity.ok().body("Marca deleted successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> GetById(@PathVariable final Long id){
        try{
            Optional<Marca> res = this.marcaRepository.findById(id);
            Marca existingMarca = res.orElseThrow(() -> new Exception("Marca não encontrada"));

            return ResponseEntity.ok().body(existingMarca);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping()
    public ResponseEntity<?> GetById(){
        try{
            List<Marca> marcas = this.marcaRepository.findAll();

            return ResponseEntity.ok().body(marcas);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
