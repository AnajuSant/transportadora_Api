package br.com.uniamerica.trasnportadora.transportadoraapi.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name= "td_caminhao", schema = "transportadora")
public class Caminhao extends AbstractEntity{
    @Getter @Setter
    private String placa;

    @Getter @Setter
    @ManyToOne
    private Modelo modelo;

    @Getter @Setter
    @ManyToOne
    private Usuario motorista;

    @Getter @Setter
    private int ano;

    @Getter @Setter
    private Cor cor;

    @Getter @Setter
    private String observacao;


}
