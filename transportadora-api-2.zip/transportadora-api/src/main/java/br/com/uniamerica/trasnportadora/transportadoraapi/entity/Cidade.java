package br.com.uniamerica.trasnportadora.transportadoraapi.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name= "td_cidade", schema = "transportadora")
public class Cidade extends AbstractEntity {
    @Getter @Setter
    private String nome;

    @Getter @Setter
    @ManyToOne
    private Estado estado;
}
