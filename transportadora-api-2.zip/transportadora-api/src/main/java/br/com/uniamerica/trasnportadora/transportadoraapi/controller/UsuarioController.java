package br.com.uniamerica.trasnportadora.transportadoraapi.controller;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Usuario;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Controller
@RequestMapping("/api/usuario")
public class UsuarioController {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @PostMapping
    public ResponseEntity<String> Post(@RequestBody final Usuario usuario){
        try{
            this.usuarioRepository.save(usuario);
            return ResponseEntity.ok().body("User saved successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<String> Put(@PathVariable final Long id, @RequestBody final Usuario usuario){
        try{
            Optional<Usuario> res = this.usuarioRepository.findById(id);
            Usuario existingUser = res.orElseThrow(() -> new Exception("Usuario não encontrado"));

            existingUser.setNome(usuario.getNome());
            existingUser.setLogin(usuario.getLogin());
            existingUser.setSenha(usuario.getSenha());
            existingUser.setCpf(usuario.getCpf());
            existingUser.setEndereco(usuario.getEndereco());
            existingUser.setTelefone(usuario.getTelefone());
            existingUser.setPercoGanho(usuario.getPercoGanho());
            existingUser.setObservacao(usuario.getObservacao());
            existingUser.setDataNascimento(usuario.getDataNascimento());
            existingUser.setGrupo(usuario.getGrupo());

            this.usuarioRepository.save(existingUser);
            return ResponseEntity.ok().body("User updated successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> Delete(@PathVariable final Long id){
        try{
            Optional<Usuario> res = this.usuarioRepository.findById(id);
            Usuario existingUser = res.orElseThrow(() -> new Exception("Usuario não encontrado"));

            this.usuarioRepository.delete(existingUser);
            return ResponseEntity.ok().body("User deleted successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> GetById(@PathVariable final Long id){
        try{
            Optional<Usuario> res = this.usuarioRepository.findById(id);
            Usuario existingUser = res.orElseThrow(() -> new Exception("Usuario não encontrado"));

            return ResponseEntity.ok().body(existingUser);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping()
    public ResponseEntity<?> GetById(){
        try{
            List<Usuario> usuarios = this.usuarioRepository.findAll();

            return ResponseEntity.ok().body(usuarios);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
