package br.com.uniamerica.trasnportadora.transportadoraapi.controller;

import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Cidade;
import br.com.uniamerica.trasnportadora.transportadoraapi.entity.Despesas;
import br.com.uniamerica.trasnportadora.transportadoraapi.repository.DespesaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/api/despesa")
public class DespesaController {
    @Autowired
    private DespesaRepository despesaRepository;

    @PostMapping
    public ResponseEntity<String> Post(@RequestBody final Despesas despesa){
        try{
            this.despesaRepository.save(despesa);
            return ResponseEntity.ok().body("Despesa saved successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<String> Put(@PathVariable final Long id, @RequestBody final Despesas despesa){
        try{
            Optional<Despesas> res = this.despesaRepository.findById(id);
            Despesas existingDespesa = res.orElseThrow(() -> new Exception("Despesa não encontrada"));

            existingDespesa.setTipoDespesa(despesa.getTipoDespesa());
            existingDespesa.setData(despesa.getData());
            existingDespesa.setAprovador(despesa.getAprovador());
            existingDespesa.setValor(despesa.getValor());
            existingDespesa.setMotorista(despesa.getMotorista());
            existingDespesa.setFrete(despesa.getFrete());

            this.despesaRepository.save(existingDespesa);
            return ResponseEntity.ok().body("Despesa updated successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> Delete(@PathVariable final Long id){
        try{
            Optional<Despesas> res = this.despesaRepository.findById(id);
            Despesas existingDespesa = res.orElseThrow(() -> new Exception("Despesa não encontrada"));

            this.despesaRepository.delete(existingDespesa);
            return ResponseEntity.ok().body("Despesa deleted successfully");
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> GetById(@PathVariable final Long id){
        try{
            Optional<Despesas> res = this.despesaRepository.findById(id);
            Despesas existingDespesa = res.orElseThrow(() -> new Exception("Despesa não encontrada"));

            return ResponseEntity.ok().body(existingDespesa);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @GetMapping()
    public ResponseEntity<?> GetById(){
        try{
            List<Despesas> despesas = this.despesaRepository.findAll();

            return ResponseEntity.ok().body(despesas);
        } catch (Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }
}
