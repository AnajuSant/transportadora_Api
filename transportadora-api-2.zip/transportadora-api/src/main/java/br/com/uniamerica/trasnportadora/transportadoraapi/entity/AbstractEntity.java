package br.com.uniamerica.trasnportadora.transportadoraapi.entity;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.time.LocalDateTime;

@MappedSuperclass
public abstract class AbstractEntity {

    @Getter
    @Setter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Getter @Setter
    @CreationTimestamp
    private LocalDateTime cadastrado;

    @Getter @Setter
    @UpdateTimestamp
    private LocalDateTime atualizado;

    @Getter @Setter
    private boolean ativo = true;


}
